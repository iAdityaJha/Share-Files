"""
rag.py
------
Retrieval-Augmented Generation layer for the Galaxy Forever knowledge base.

Primary path: sentence-transformers embeddings + ChromaDB (local, in-memory) vector store.
Fallback path: if those libraries are unavailable in the environment, falls back to a
simple keyword-overlap retriever so the rest of the pipeline still runs end-to-end.

Each KB record is flattened into a single text blob for embedding, combining
campaign_type, objective, offer_details, tone, visual_style, keywords, etc.
"""

import json
from pathlib import Path
from typing import List, Dict

DATA_PATH = Path(__file__).resolve().parent.parent / "data" / "galaxy_forever_kb.json"


def _load_kb() -> List[Dict]:
    with open(DATA_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


def _record_to_text(record: Dict) -> str:
    """Flattens a KB record into a single retrievable text blob."""
    parts = [
        record.get("campaign_name", ""),
        record.get("campaign_type", ""),
        record.get("audience", ""),
        record.get("objective", ""),
        record.get("offer_details", ""),
        record.get("tone", ""),
        record.get("visual_style", ""),
        record.get("colors", ""),
        record.get("cta", ""),
        record.get("raw_prompt", ""),
        " ".join(record.get("keywords", [])),
    ]
    return ". ".join(p for p in parts if p)


class _EmbeddingRetriever:
    """Vector retriever using sentence-transformers + ChromaDB (preferred path)."""

    def __init__(self, kb: List[Dict]):
        import chromadb
        from sentence_transformers import SentenceTransformer

        self.kb = kb
        self.model = SentenceTransformer("all-MiniLM-L6-v2")
        self.client = chromadb.Client()  # in-memory, ephemeral — fine for an MVP demo
        self.collection = self.client.get_or_create_collection(name="galaxy_forever_kb")

        texts = [_record_to_text(r) for r in kb]
        embeddings = self.model.encode(texts).tolist()
        ids = [r["id"] for r in kb]
        self.collection.add(
            ids=ids,
            embeddings=embeddings,
            documents=texts,
            metadatas=kb,
        )

    def retrieve(self, query: str, top_k: int = 2) -> List[Dict]:
        query_embedding = self.model.encode([query]).tolist()
        results = self.collection.query(query_embeddings=query_embedding, n_results=top_k)
        metadatas = results.get("metadatas", [[]])[0]
        return metadatas


class _KeywordRetriever:
    """Fallback retriever: simple keyword/word-overlap scoring, zero extra dependencies."""

    def __init__(self, kb: List[Dict]):
        self.kb = kb

    def retrieve(self, query: str, top_k: int = 2) -> List[Dict]:
        query_words = set(query.lower().split())
        scored = []
        for record in self.kb:
            text = _record_to_text(record).lower()
            record_words = set(text.replace(",", " ").replace(".", " ").split())
            overlap = len(query_words & record_words)
            scored.append((overlap, record))
        scored.sort(key=lambda x: x[0], reverse=True)
        return [r for _, r in scored[:top_k]]


class GalaxyForeverRetriever:
    """
    Public RAG interface used by the pipeline.
    Tries the embedding-based retriever first; falls back to keyword retrieval
    if sentence-transformers/chromadb are not installed or fail to load.
    """

    def __init__(self):
        self.kb = _load_kb()
        try:
            self._engine = _EmbeddingRetriever(self.kb)
            self.backend = "sentence-transformers + chromadb"
        except Exception:
            self._engine = _KeywordRetriever(self.kb)
            self.backend = "keyword-overlap fallback"

    def retrieve(self, cleaned_prompt: str, top_k: int = 2) -> List[Dict]:
        if not self.kb:
            return []
        top_k = min(top_k, len(self.kb))
        return self._engine.retrieve(cleaned_prompt, top_k=top_k)

    @staticmethod
    def format_context(records: List[Dict]) -> str:
        """Formats retrieved records into a readable context block for the LLM prompt."""
        blocks = []
        for i, r in enumerate(records, start=1):
            blocks.append(
                f"[Context {i}] campaign_type: {r.get('campaign_type')}\n"
                f"  objective: {r.get('objective')}\n"
                f"  offer_details: {r.get('offer_details')}\n"
                f"  tone: {r.get('tone')}\n"
                f"  visual_style: {r.get('visual_style')}\n"
                f"  colors: {r.get('colors')}\n"
                f"  cta: {r.get('cta')}\n"
                f"  example_enhanced_prompt: {r.get('enhanced_prompt')}"
            )
        return "\n\n".join(blocks)
