"""
pruning.py
----------
Prompt pruning / cleaning logic.

This runs AFTER input guardrails pass, and BEFORE RAG retrieval.
Its job is purely to clean up the text — it does not reject anything
(that's the guardrails' job). It:
  - strips filler / small-talk phrases
  - removes redundant whitespace/punctuation
  - removes personal/unrelated comments
  - keeps only the business-relevant core intent

This is intentionally rule-based and lightweight for the MVP.
"""

import json
import re
from pathlib import Path

RULES_PATH = Path(__file__).resolve().parent.parent / "data" / "guardrail_rules.json"

with open(RULES_PATH, "r", encoding="utf-8") as f:
    _RULES = json.load(f)

FILLER_PATTERNS = _RULES.get("irrelevant_filler_patterns", [])


def prune_prompt(raw_prompt: str) -> str:
    """
    Cleans a raw business prompt and returns a pruned version
    suitable for embedding / retrieval / LLM input.
    """
    text = raw_prompt.strip()

    # 1. Remove known filler / off-topic phrases (case-insensitive, word-boundary safe)
    for phrase in FILLER_PATTERNS:
        pattern = re.compile(re.escape(phrase), re.IGNORECASE)
        text = pattern.sub("", text)

    # 2. Remove emojis and non-standard symbols
    text = re.sub(r"[^\w\s%/+&'-]", " ", text)

    # 3. Collapse repeated punctuation/whitespace
    text = re.sub(r"\s{2,}", " ", text).strip()

    # 4. Remove leading/trailing stray punctuation left after stripping filler
    text = text.strip(" -,.;:")

    # 5. If pruning emptied the string (e.g. it was ONLY filler), fall back to
    #    the original trimmed text so downstream stages still have something
    #    to work with — the guardrails stage should normally catch pure filler
    #    before we get here.
    if not text:
        text = raw_prompt.strip()

    return text
