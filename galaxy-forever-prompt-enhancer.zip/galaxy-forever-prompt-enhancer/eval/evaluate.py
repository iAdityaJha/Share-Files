"""
evaluate.py
-----------
Simple evaluation harness for the Galaxy Forever prompt enhancement pipeline.

Run with:
    python eval/evaluate.py

Prints a pass/fail table comparing actual pipeline status against the
expected status for each test case in eval/test_cases.json, plus a
raw-prompt-vs-enhanced-prompt printout for manual quality review.
"""

import json
import sys
from pathlib import Path

# Make project root importable when running this script directly
sys.path.insert(0, str(Path(__file__).resolve().parent.parent))

from src.pipeline import run_pipeline  # noqa: E402

TEST_CASES_PATH = Path(__file__).resolve().parent / "test_cases.json"


def main():
    with open(TEST_CASES_PATH, "r", encoding="utf-8") as f:
        test_cases = json.load(f)

    passed_count = 0
    print("=" * 90)
    print("GALAXY FOREVER PROMPT ENHANCER — EVALUATION RUN")
    print("=" * 90)

    for tc in test_cases:
        result = run_pipeline(tc["raw_prompt"])
        actual_status = result["status"]
        ok = actual_status == tc["expected_status"]
        passed_count += int(ok)

        print(f"\n[{tc['id']}] ({tc['category']}) — {'PASS' if ok else 'FAIL'}")
        print(f"  raw_prompt        : {tc['raw_prompt']!r}")
        print(f"  expected_status   : {tc['expected_status']}")
        print(f"  actual_status     : {actual_status}")
        if "cleaned_prompt" in result:
            print(f"  cleaned_prompt    : {result['cleaned_prompt']!r}")
        if result.get("retrieved_records"):
            top_ids = [r.get("id") for r in result["retrieved_records"]]
            print(f"  retrieved_ids     : {top_ids}  (backend: {result.get('retrieval_backend')})")
        if result.get("final_prompt"):
            print(f"  enhanced_prompt   : {result['final_prompt']}")
            print(f"  enhancement_source: {result.get('enhancement_source')}")
        if actual_status != "success":
            reason = (result.get("input_guardrail") or {}).get("reason") or \
                      (result.get("output_guardrail") or {}).get("reason")
            print(f"  rejection_reason  : {reason}")

    print("\n" + "=" * 90)
    print(f"RESULT: {passed_count}/{len(test_cases)} test cases passed")
    print("=" * 90)


if __name__ == "__main__":
    main()
