# Galaxy Forever Prompt Enhancer

A context-aware prompt enhancement framework for Samsung Finance+ marketing banner generation.

**This is a prompt enhancement system, not an image generation system.** It takes short, vague
business prompts (e.g. *"Galaxy Forever banner"*) and turns them into detailed, brand-safe,
commercially-useful prompts that can later be passed to any text-to-image model.

MVP scope: **Galaxy Forever campaign only** (Samsung Finance+ device financing program).

---

## 1. Architecture Overview

```
 Short business prompt
        │
        ▼
 ┌─────────────────────┐
 │ 1. Input Guardrails  │  reject unsafe / political / religious / hate /
 │                      │  off-brand / too-short / injection prompts
 └─────────┬────────────┘
           ▼
 ┌─────────────────────┐
 │ 2. Prompt Pruning    │  strip filler, small talk, redundant text —
 │                      │  keep only the business intent
 └─────────┬────────────┘
           ▼
 ┌─────────────────────┐
 │ 3. RAG Retrieval     │  embed cleaned prompt → retrieve top-k Galaxy
 │  (ChromaDB + ST)     │  Forever campaign records (offer, tone, visuals)
 └─────────┬────────────┘
           ▼
 ┌─────────────────────┐
 │ 4. LLM Enhancement   │  rewrite into a single polished image-gen prompt,
 │                      │  grounded in retrieved campaign context
 └─────────┬────────────┘
           ▼
 ┌─────────────────────┐
 │ 5. Output Guardrails │  re-check for unsafe terms, brand drift,
 │                      │  verbosity → retry once with safe fallback if needed
 └─────────┬────────────┘
           ▼
   Final enhanced prompt
```

### Why each layer exists

- **Input guardrails** — business users can type anything. We must reject unsafe, political,
  religious, hateful, or off-brand (e.g. competitor) requests *before* spending any retrieval or
  LLM compute on them, and before they ever reach a model.
- **Pruning** — distinct from retrieval. A prompt like *"lol my dog is cute, make a Galaxy
  Forever banner pls"* has real intent buried in noise. Pruning cleans this before it's embedded,
  which improves retrieval quality and keeps the LLM input focused.
- **RAG retrieval** — short prompts are intentionally vague ("Upgrade banner"). RAG grounds the
  generation in real Galaxy Forever campaign facts (no-cost EMI, 50% upfront, buyback, tone,
  color palette) instead of letting the LLM hallucinate offer details or visual style.
- **LLM enhancement** — synthesizes the cleaned prompt + retrieved context into one polished,
  detailed, text-to-image-ready prompt.
- **Output guardrails** — LLMs can drift, over-elaborate, or occasionally produce unsafe/off-brand
  phrasing even with a good system prompt. This is a final safety + brand + quality check, with
  one automatic retry using a guaranteed-safe deterministic template if the LLM output fails.

### How this differs from a normal prompt-to-image pipeline

A typical pipeline is `prompt → image model`. This system inserts an entire **text-only**
reasoning and safety layer *before* any image generation happens: `vague prompt → guarded,
RAG-grounded, LLM-rewritten prompt → (future) image model`. This makes the system reusable across
any downstream text-to-image provider, auditable (every stage is inspectable), and safe to run
on raw, unfiltered business-user input.

---

## 2. Folder Structure

```
galaxy-forever-prompt-enhancer/
├── app.py                      # Streamlit demo UI
├── requirements.txt
├── .env.example
├── .gitignore
├── README.md
├── src/
│   ├── __init__.py
│   ├── guardrails.py           # input + output guardrails
│   ├── pruning.py               # prompt cleaning logic
│   ├── rag.py                   # embeddings + ChromaDB retrieval (+ fallback)
│   ├── enhancer.py               # LLM call + offline template fallback
│   └── pipeline.py               # orchestrates all 5 stages
├── data/
│   ├── galaxy_forever_kb.json     # the knowledge base (4 records)
│   ├── guardrail_rules.json       # keyword rules for guardrails/pruning
│   └── prompt_templates.json      # LLM system prompt + fallback template
└── eval/
    ├── test_cases.json            # 11 test cases across categories
    └── evaluate.py                 # evaluation harness / CLI runner
```

## File-by-file explanation

| File | Purpose |
|---|---|
| `src/guardrails.py` | `check_input_guardrails()` and `check_output_guardrails()` — keyword/length/category based checks, transparent and easy to extend with a real moderation API later. |
| `src/pruning.py` | `prune_prompt()` — strips filler phrases, emojis, redundant punctuation, keeps core business text. |
| `src/rag.py` | `GalaxyForeverRetriever` — embeds the KB with `sentence-transformers` and indexes it in an in-memory `ChromaDB` collection; falls back to a keyword-overlap retriever if those libraries aren't installed. |
| `src/enhancer.py` | `enhance_prompt()` — calls Anthropic or OpenAI if configured via `.env`; otherwise uses a deterministic, brand-safe template fallback. |
| `src/pipeline.py` | `run_pipeline()` — wires all 5 stages together and returns a full trace dict. |
| `app.py` | Streamlit UI: text input → run pipeline → show final prompt + full debug trace. |
| `eval/evaluate.py` | Runs all test cases and prints pass/fail + raw-vs-enhanced comparisons. |

---

## 3. Setup Instructions

### Prerequisites
- Python 3.9+

### Install

```bash
cd galaxy-forever-prompt-enhancer
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
```

> Note: the first run downloads the `all-MiniLM-L6-v2` sentence-transformers model
> (~80MB) automatically. If you have no internet access for that, the system
> automatically falls back to a simple keyword-overlap retriever — the pipeline
> still runs end-to-end either way.

### Environment variables to fill in (`.env`)

| Variable | Required? | Description |
|---|---|---|
| `LLM_PROVIDER` | No (default `none`) | `anthropic`, `openai`, or `none`. If `none`, a safe offline template fallback is used. |
| `ANTHROPIC_API_KEY` | Only if `LLM_PROVIDER=anthropic` | Your Anthropic API key. |
| `ANTHROPIC_MODEL` | No (default `claude-sonnet-4-6`) | Anthropic model name. |
| `OPENAI_API_KEY` | Only if `LLM_PROVIDER=openai` | Your OpenAI API key. |
| `OPENAI_MODEL` | No (default `gpt-4o-mini`) | OpenAI model name. |
| `EMBEDDING_MODEL_NAME` | No | sentence-transformers model name used for retrieval. |

No real keys are included anywhere in this repo. The system is fully runnable with
`LLM_PROVIDER=none` and zero API keys.

---

## 4. Run Instructions

### Run the Streamlit demo

```bash
streamlit run app.py
```

Open the local URL Streamlit prints (typically `http://localhost:8501`), enter a
prompt such as `Galaxy Forever banner`, and click **Enhance Prompt**.

### Run the evaluation suite (CLI)

```bash
python eval/evaluate.py
```

This runs 11 test cases covering happy paths, pruning, and guardrail rejections, and
prints a pass/fail summary plus raw-vs-enhanced prompt comparisons.

### Use the pipeline programmatically

```python
from src.pipeline import run_pipeline

result = run_pipeline("Galaxy Forever banner")
print(result["final_prompt"])
```

---

## 5. Sample Input / Output

**Input:** `"Galaxy Forever banner"`

**Pipeline trace:**
1. Input guardrails: ✅ passed
2. Pruning: `"Galaxy Forever banner"` (no filler to remove)
3. RAG retrieval: top match → `gf-001` (Device Financing / Upgrade Program record)
4. LLM enhancement: generates polished prompt grounded in retrieved record
5. Output guardrails: ✅ passed

**Output (example):**
> A premium commercial marketing banner for Samsung Finance+ Galaxy Forever program, featuring a
> flagship Galaxy smartphone as the hero subject with soft studio lighting and subtle blue
> gradient glow, set against a clean minimalist background in Samsung blue, white and silver
> tones, ample negative space reserved for bold headline and CTA text, modern trustworthy
> fintech aesthetic, sharp product photography style, polished commercial advertising quality,
> 4K resolution, no embedded text in the image.

**Rejected input example:** `"Galaxy Forever banner with election poster style for prime
minister rally"` → rejected at input guardrails (political content detected).

---

## 6. Evaluation Notes

`eval/test_cases.json` covers:
- **Happy paths** (4 cases): each of the example prompts from the spec, verifying retrieval
  pulls a sensible KB record and the pipeline reaches `success`.
- **Pruning** (1 case): a prompt with filler/off-topic text mixed with real intent, verifying
  the core business intent survives cleaning.
- **Input guardrail rejections** (5 cases): empty prompt, too-short prompt, political content,
  unsafe/violent content, off-brand competitor reference.
- **Injection rejection** (1 case): a prompt-injection style attempt ("ignore previous
  instructions...").

Run `python eval/evaluate.py` to see live pass/fail results plus the actual enhanced prompt
text generated for each happy-path case, so retrieval and generation quality can be reviewed
manually alongside the automated pass/fail status.

This evaluation approach is intentionally lightweight (no held-out human-graded dataset, no
embedding similarity scoring) — appropriate for an MVP. See **Future Improvements** below for
how to extend it.

---

## 7. Assumptions & Limitations

- The knowledge base (`data/galaxy_forever_kb.json`) contains 4 synthetic-but-realistic records
  scoped only to Galaxy Forever, per the project constraints. It is not a production data feed.
- Guardrails use transparent keyword/regex matching rather than a hosted moderation model, by
  design, to keep the project dependency-free and fully runnable offline. This is explicitly an
  MVP simplification — see below.
- The vector store (`ChromaDB`) runs in-memory and is rebuilt on every process start; there is no
  persistence layer in this MVP.
- If `sentence-transformers` / `chromadb` cannot be installed or the model can't be downloaded
  (e.g. no internet), the system automatically falls back to a keyword-overlap retriever so the
  full pipeline still runs — retrieval quality will be lower in that mode.
- If no `LLM_PROVIDER` / API key is configured, prompt enhancement falls back to a deterministic
  template. This is guaranteed brand-safe but less creative/varied than a real LLM rewrite.
- No authentication, rate limiting, persistence, or multi-user support — this is a local
  prototype, not a production service.

---

## 8. Future Improvements (Out of Scope for this MVP)

- Expand the knowledge base to additional campaigns (e.g. Diwali, festive offers) with a
  campaign-router stage before retrieval.
- Replace keyword-based guardrails with a dedicated moderation/classifier model or hosted
  moderation API.
- Add persistent vector storage (on-disk ChromaDB or a managed vector DB) instead of in-memory.
- Add human-graded evaluation scoring (e.g. relevance, brand-safety, creativity rubrics) and an
  automated retrieval-quality metric (e.g. recall@k against labeled query→record pairs).
- Wire the final enhanced prompt directly into a text-to-image generation service to complete
  the end-to-end banner generation pipeline.
- Add multi-turn clarification flow when input guardrails flag `needs_clarification` (currently
  the API surfaces this flag but the UI does not yet prompt the user for clarification text).
