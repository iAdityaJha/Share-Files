"""
guardrails.py
--------------
Input and output guardrails for the prompt enhancement pipeline.

Design notes (MVP scope):
- Uses transparent keyword/regex based checks instead of a hosted moderation
  API, so the project runs fully offline with zero external dependencies.
- Swap `_contains_any` checks for a real moderation/classifier call in
  production (e.g. an LLM-based safety classifier or a moderation API).
"""

import json
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import List

RULES_PATH = Path(__file__).resolve().parent.parent / "data" / "guardrail_rules.json"


def _load_rules() -> dict:
    with open(RULES_PATH, "r", encoding="utf-8") as f:
        return json.load(f)


RULES = _load_rules()


@dataclass
class GuardrailResult:
    passed: bool
    stage: str  # "input" or "output"
    reason: str = ""
    flagged_terms: List[str] = field(default_factory=list)
    needs_clarification: bool = False


def _contains_any(text: str, terms: List[str]) -> List[str]:
    text_lower = text.lower()
    hits = []
    for term in terms:
        if term.lower() in text_lower:
            hits.append(term)
    return hits


def check_input_guardrails(raw_prompt: str) -> GuardrailResult:
    """
    Validates a raw incoming business prompt BEFORE any pruning or retrieval.
    Returns a GuardrailResult indicating pass/fail and the reason.
    """
    text = (raw_prompt or "").strip()

    # 1. Empty or too short
    if len(text) < RULES["min_prompt_length"]:
        return GuardrailResult(
            passed=False,
            stage="input",
            reason="Prompt is empty or too short to convey business intent.",
            needs_clarification=True,
        )

    # 2. Too long (likely spam / irrelevant rambling)
    if len(text) > RULES["max_prompt_length"]:
        return GuardrailResult(
            passed=False,
            stage="input",
            reason=f"Prompt exceeds maximum allowed length of {RULES['max_prompt_length']} characters.",
            needs_clarification=True,
        )

    # 3. Blocked categories: unsafe, political, religious, hate, adult, competitor
    flagged = []
    for category, terms in RULES["blocked_categories"].items():
        hits = _contains_any(text, terms)
        if hits:
            flagged.extend(hits)

    if flagged:
        return GuardrailResult(
            passed=False,
            stage="input",
            reason=f"Prompt contains disallowed content for categories: {flagged}",
            flagged_terms=flagged,
        )

    # 4. Prompt-injection style attempts (e.g. "ignore previous instructions")
    injection_hits = _contains_any(text, [
        "ignore previous instructions", "ignore all instructions",
        "system prompt", "you are now", "act as"
    ])
    if injection_hits:
        return GuardrailResult(
            passed=False,
            stage="input",
            reason="Prompt appears to contain an instruction-override / injection attempt.",
            flagged_terms=injection_hits,
        )

    return GuardrailResult(passed=True, stage="input")


def check_output_guardrails(enhanced_prompt: str) -> GuardrailResult:
    """
    Validates the LLM-generated enhanced prompt AFTER generation,
    before returning it to the caller.
    """
    text = (enhanced_prompt or "").strip()

    if not text:
        return GuardrailResult(passed=False, stage="output", reason="Generated prompt is empty.")

    # 1. Blocked/unsafe terms in the output
    flagged = _contains_any(text, RULES["output_blocked_terms"])
    if flagged:
        return GuardrailResult(
            passed=False,
            stage="output",
            reason=f"Generated prompt contains disallowed terms: {flagged}",
            flagged_terms=flagged,
        )

    # 2. Brand context check — must still be anchored to Galaxy Forever / Samsung context
    brand_hits = _contains_any(text, RULES["brand_safety_terms_required_context"])
    if not brand_hits:
        return GuardrailResult(
            passed=False,
            stage="output",
            reason="Generated prompt has drifted away from Samsung Galaxy Forever campaign context.",
        )

    # 3. Verbosity check
    word_count = len(re.findall(r"\w+", text))
    if word_count > RULES["max_enhanced_prompt_words"]:
        return GuardrailResult(
            passed=False,
            stage="output",
            reason=f"Generated prompt is too verbose ({word_count} words, "
                   f"max {RULES['max_enhanced_prompt_words']}).",
        )

    return GuardrailResult(passed=True, stage="output")
