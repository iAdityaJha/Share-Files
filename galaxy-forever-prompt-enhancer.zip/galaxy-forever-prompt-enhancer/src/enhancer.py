"""
enhancer.py
-----------
LLM layer that rewrites the cleaned, RAG-grounded prompt into a polished
text-to-image prompt.

Configuration (via environment variables — see .env.example):
  LLM_PROVIDER         "anthropic" | "openai" | "gauss" | "none"   (default: "none")
  ANTHROPIC_API_KEY    required if LLM_PROVIDER=anthropic
  ANTHROPIC_MODEL      e.g. "claude-sonnet-4-6" (default)
  OPENAI_API_KEY       required if LLM_PROVIDER=openai
  OPENAI_MODEL         e.g. "gpt-4o-mini" (default)
  GAUSS_API_KEY        required if LLM_PROVIDER=gauss
  GAUSS_API_BASE_URL   required if LLM_PROVIDER=gauss — your Gauss endpoint URL
  GAUSS_MODEL          e.g. "gauss-2" (default)

If LLM_PROVIDER is "none" (or no key is configured / the call fails),
the system falls back to a deterministic, template-based enhancer built
from the prompt_templates.json + retrieved KB context. This keeps the
project fully runnable out of the box with zero external API access,
while still demonstrating the full architecture end-to-end.
"""

import json
import os
from pathlib import Path
from typing import List, Dict

TEMPLATES_PATH = Path(__file__).resolve().parent.parent / "data" / "prompt_templates.json"

with open(TEMPLATES_PATH, "r", encoding="utf-8") as f:
    TEMPLATES = json.load(f)


def _build_user_message(cleaned_prompt: str, retrieved_context: str) -> str:
    return TEMPLATES["user_template"].format(
        cleaned_prompt=cleaned_prompt,
        retrieved_context=retrieved_context,
    )


def _fallback_enhance(cleaned_prompt: str, retrieved_records: List[Dict]) -> str:
    """
    Deterministic, no-API-key-required enhancer.
    Picks the most relevant retrieved record's offer focus and merges it
    into the fallback template. This guarantees a usable demo offline.
    """
    if retrieved_records:
        top = retrieved_records[0]
        offer_focus = top.get("offer_details", "no-cost EMI and 50% upfront payment")
    else:
        offer_focus = "no-cost EMI, 50% upfront payment, and assured buyback"

    return TEMPLATES["fallback_template"].format(offer_focus=offer_focus)


def _call_anthropic(system: str, user_message: str) -> str:
    import requests

    api_key = os.environ.get("ANTHROPIC_API_KEY")
    model = os.environ.get("ANTHROPIC_MODEL", "claude-sonnet-4-6")
    if not api_key:
        raise RuntimeError("ANTHROPIC_API_KEY not set")

    response = requests.post(
        "https://api.anthropic.com/v1/messages",
        headers={
            "x-api-key": api_key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
        json={
            "model": model,
            "max_tokens": 400,
            "system": system,
            "messages": [{"role": "user", "content": user_message}],
        },
        timeout=30,
    )
    response.raise_for_status()
    data = response.json()
    text_blocks = [b["text"] for b in data.get("content", []) if b.get("type") == "text"]
    return " ".join(text_blocks).strip()


def _call_openai(system: str, user_message: str) -> str:
    import requests

    api_key = os.environ.get("OPENAI_API_KEY")
    model = os.environ.get("OPENAI_MODEL", "gpt-4o-mini")
    if not api_key:
        raise RuntimeError("OPENAI_API_KEY not set")

    response = requests.post(
        "https://api.openai.com/v1/chat/completions",
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": model,
            "max_tokens": 400,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user_message},
            ],
        },
        timeout=30,
    )
    response.raise_for_status()
    data = response.json()
    return data["choices"][0]["message"]["content"].strip()


def _call_gauss(system: str, user_message: str) -> str:
    """
    Calls a Samsung Gauss endpoint. Assumes an OpenAI-compatible
    chat-completions request/response shape (most Gauss deployments and
    gateways expose this). If your specific endpoint's request/response
    schema differs, adjust the `json=` payload and the response parsing
    below to match your endpoint's actual contract.
    """
    import requests

    api_key = os.environ.get("GAUSS_API_KEY")
    base_url = os.environ.get("GAUSS_API_BASE_URL")
    model = os.environ.get("GAUSS_MODEL", "gauss-2")

    if not api_key:
        raise RuntimeError("GAUSS_API_KEY not set")
    if not base_url:
        raise RuntimeError("GAUSS_API_BASE_URL not set")

    response = requests.post(
        base_url,
        headers={
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
        },
        json={
            "model": model,
            "max_tokens": 400,
            "messages": [
                {"role": "system", "content": system},
                {"role": "user", "content": user_message},
            ],
        },
        timeout=30,
    )
    response.raise_for_status()
    data = response.json()

    # OpenAI-compatible shape: { "choices": [ { "message": { "content": "..." } } ] }
    if "choices" in data:
        return data["choices"][0]["message"]["content"].strip()

    # Fallback: some gateways return { "content": "..." } or { "output": "..." } directly.
    if "content" in data:
        return str(data["content"]).strip()
    if "output" in data:
        return str(data["output"]).strip()

    raise RuntimeError(f"Unrecognized Gauss response shape: {list(data.keys())}")


def enhance_prompt(cleaned_prompt: str, retrieved_records: List[Dict]) -> Dict:
    """
    Returns a dict: {"enhanced_prompt": str, "source": "llm:<provider>" | "fallback_template"}
    """
    provider = os.environ.get("LLM_PROVIDER", "none").lower()
    retrieved_context = (
        _format_context_for_llm(retrieved_records) if retrieved_records else "No campaign context retrieved."
    )
    system = TEMPLATES["system_instruction"]
    user_message = _build_user_message(cleaned_prompt, retrieved_context)

    try:
        if provider == "anthropic":
            text = _call_anthropic(system, user_message)
            if text:
                return {"enhanced_prompt": text, "source": "llm:anthropic"}
        elif provider == "openai":
            text = _call_openai(system, user_message)
            if text:
                return {"enhanced_prompt": text, "source": "llm:openai"}
        elif provider == "gauss":
            text = _call_gauss(system, user_message)
            if text:
                return {"enhanced_prompt": text, "source": "llm:gauss"}
    except Exception as e:
        # Any API/network/auth error silently falls back so the demo never hard-crashes.
        print(f"[enhancer] LLM call failed, using fallback template. Reason: {e}")

    # provider == "none", or above failed
    return {
        "enhanced_prompt": _fallback_enhance(cleaned_prompt, retrieved_records),
        "source": "fallback_template",
    }


def _format_context_for_llm(records: List[Dict]) -> str:
    from src.rag import GalaxyForeverRetriever
    return GalaxyForeverRetriever.format_context(records)
