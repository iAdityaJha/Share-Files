"""
app.py
------
Lightweight Streamlit demo UI for the Galaxy Forever Prompt Enhancement pipeline.

Run with:
    streamlit run app.py
"""

import streamlit as st
from dotenv import load_dotenv

load_dotenv()  # picks up .env if present

from src.pipeline import run_pipeline  # noqa: E402

st.set_page_config(page_title="Galaxy Forever Prompt Enhancer", page_icon="📱", layout="centered")

st.title("📱 Samsung Finance+ — Galaxy Forever Prompt Enhancer")
st.caption(
    "Turns short, vague business prompts into rich, brand-safe text-to-image prompts "
    "using guardrails + pruning + RAG + LLM rewriting."
)

with st.sidebar:
    st.subheader("Pipeline settings")
    top_k = st.slider("RAG top-k context records", min_value=1, max_value=4, value=2)
    st.markdown("---")
    st.markdown(
        "**LLM provider:** set via `LLM_PROVIDER` env var (`anthropic` / `openai` / `none`).\n\n"
        "If unset or no API key is configured, a deterministic template-based "
        "fallback is used so the demo always runs."
    )
    st.markdown("---")
    st.subheader("Try these examples")
    for example in [
        "Galaxy Forever banner",
        "Galaxy Forever EMI offer",
        "Premium Galaxy campaign",
        "Upgrade banner",
        "lol my dog is cute, make a Galaxy Forever banner pls",
        "Galaxy Forever banner with election poster style",
    ]:
        st.code(example, language=None)

raw_prompt = st.text_input("Enter a short business prompt", value="Galaxy Forever banner")
run_button = st.button("Enhance Prompt", type="primary")

if run_button:
    if not raw_prompt or not raw_prompt.strip():
        st.warning("Please enter a prompt.")
    else:
        with st.spinner("Running pipeline: guardrails → pruning → RAG → LLM → guardrails..."):
            result = run_pipeline(raw_prompt, top_k=top_k)

        status = result["status"]

        if status == "rejected_at_input":
            st.error(f"❌ Rejected at input guardrails: {result['input_guardrail']['reason']}")
        elif status == "rejected_at_output":
            st.error(f"❌ Rejected at output guardrails (after retry): {result['output_guardrail']['reason']}")
        else:
            st.success("✅ Enhanced prompt generated")
            st.markdown("### Final Enhanced Prompt")
            st.text_area("Copy this into your text-to-image model:", result["final_prompt"], height=160)

        with st.expander("🔍 Pipeline trace (for debugging / evaluation)"):
            st.json(result)
