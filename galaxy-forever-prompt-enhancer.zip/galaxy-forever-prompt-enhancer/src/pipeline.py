"""
pipeline.py
-----------
Orchestrates the full flow:

  raw prompt
    -> input guardrails
    -> pruning
    -> RAG retrieval
    -> LLM prompt enhancement
    -> output guardrails
    -> final enhanced prompt

Exposes a single function `run_pipeline(raw_prompt)` returning a structured
result dict so both the Streamlit UI and the evaluation script can reuse it.
"""

from typing import Dict

from src.guardrails import check_input_guardrails, check_output_guardrails
from src.pruning import prune_prompt
from src.rag import GalaxyForeverRetriever
from src.enhancer import enhance_prompt

# Retriever is initialized once (loads embedding model / builds index) and reused.
_retriever = None


def _get_retriever() -> GalaxyForeverRetriever:
    global _retriever
    if _retriever is None:
        _retriever = GalaxyForeverRetriever()
    return _retriever


def run_pipeline(raw_prompt: str, top_k: int = 2) -> Dict:
    trace = {"raw_prompt": raw_prompt}

    # 1. Input guardrails
    input_check = check_input_guardrails(raw_prompt)
    trace["input_guardrail"] = {
        "passed": input_check.passed,
        "reason": input_check.reason,
        "needs_clarification": input_check.needs_clarification,
    }
    if not input_check.passed:
        trace["status"] = "rejected_at_input"
        trace["final_prompt"] = None
        return trace

    # 2. Pruning
    cleaned_prompt = prune_prompt(raw_prompt)
    trace["cleaned_prompt"] = cleaned_prompt

    # 3. RAG retrieval
    retriever = _get_retriever()
    retrieved_records = retriever.retrieve(cleaned_prompt, top_k=top_k)
    trace["retrieval_backend"] = retriever.backend
    trace["retrieved_records"] = retrieved_records

    # 4. LLM prompt enhancement
    enhancement = enhance_prompt(cleaned_prompt, retrieved_records)
    trace["enhancement_source"] = enhancement["source"]
    candidate_prompt = enhancement["enhanced_prompt"]

    # 5. Output guardrails (with a single regeneration retry using fallback template)
    output_check = check_output_guardrails(candidate_prompt)
    if not output_check.passed:
        trace["output_guardrail_first_attempt"] = {
            "passed": False,
            "reason": output_check.reason,
        }
        # Retry once with the deterministic fallback, which is guaranteed brand-safe.
        from src.enhancer import _fallback_enhance
        candidate_prompt = _fallback_enhance(cleaned_prompt, retrieved_records)
        output_check = check_output_guardrails(candidate_prompt)

    trace["output_guardrail"] = {
        "passed": output_check.passed,
        "reason": output_check.reason,
    }

    if not output_check.passed:
        trace["status"] = "rejected_at_output"
        trace["final_prompt"] = None
        return trace

    trace["status"] = "success"
    trace["final_prompt"] = candidate_prompt
    return trace
